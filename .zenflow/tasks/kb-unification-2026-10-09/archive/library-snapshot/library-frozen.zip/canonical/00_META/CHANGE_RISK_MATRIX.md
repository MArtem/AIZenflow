# Change risk — compatibility route

The copy-only source of truth is
[../RISK_AND_EVIDENCE.md](../RISK_AND_EVIDENCE.md). This file resolves the old
`00_META/CHANGE_RISK_MATRIX.md` reference in imported materials; it adds no second risk scale.

Risk class guides review depth and evidence choice. It does not authorize tests, builds, Git,
network, installation, dependency changes, signing or release operations. If required evidence
cannot be obtained within the current task's permissions, report the limit explicitly.

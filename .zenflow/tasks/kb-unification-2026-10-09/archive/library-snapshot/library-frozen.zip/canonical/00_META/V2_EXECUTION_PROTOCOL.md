# Task execution modes — copy-only compatibility route

This document replaces the imported V2 execution dependency. It is advisory and never changes
task authority. First apply project-local instructions and the user's current scope. Then choose
the task shape supported by observed facts:

| Mode | Output |
| --- | --- |
| `IMPLEMENTATION` | Smallest coherent candidate change plus complete changed-artifact review |
| `REVIEW` | Prioritized, evidenced findings; no write inferred |
| `DIAGNOSTIC` | Reproduced or reasoned cause, uncertainty and next check; no fix inferred |
| `MIGRATION` | Source/target contract, compatibility, staged change and rollback analysis |

Before recommending a change, gather the relevant project facts using
[../PROJECT_FACTS.md](../PROJECT_FACTS.md) and
[../REPOSITORY_INSPECTION.md](../REPOSITORY_INSPECTION.md). State a compact change contract:
behavior, owner, affected producers/consumers, state/time ordering, boundaries, failure modes and
evidence. Use [../RISK_AND_EVIDENCE.md](../RISK_AND_EVIDENCE.md) to scale scrutiny, not to grant
command permission.

At each applicable stage, local work comes first; when reference is ON, the reference check
follows. Compare alternatives only when the decision's risk or ambiguity warrants it. For a
write task, inspect the complete final code/resource/project diff and re-review after material
changes. For a read-only task, give evidence-backed conclusions without inventing a diff.

Verification is limited to what the user and project permit. Separate observed, inspected,
inferred and unknown facts. Unrun build/test/runtime checks are not PASS. Do not perform a
destructive or high-impact step when ownership, data compatibility, auth/security behavior or
rollback is unresolved; ask for the missing decision.

# Evidence and verification — compatibility route

The copy-only source of truth is [../EVIDENCE_POLICY.md](../EVIDENCE_POLICY.md). This file exists
only to resolve the imported `00_META/EVIDENCE_AND_VERIFICATION_POLICY.md` name; it adds no
separate evidence standard.

An imported instruction to run builds, tests, CI, a simulator, Instruments, or network checks is
not authorization. Report missing required evidence instead of claiming PASS. A static review
cannot establish runtime behavior.

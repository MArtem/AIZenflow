# Migration review — copy-only compatibility route

This replaces the old `00_META/MIGRATION_PROTOCOL.md` reference for imported thematic material.
It is advisory, not an instruction to start or execute a migration.

For an authorized migration, establish the source and target state, data/API compatibility
window, affected producers and consumers, old-version reads, ordering, failure and rollback
semantics, and criteria for removing the legacy path. Prefer a bounded slice with observed
behavioral parity over a big-bang rewrite when that preserves user data and compatibility.

Select verification from the actual risk and permissions: old-data fixtures, migration and
negative-path tests, affected target builds, rollout observations or user-run device checks as
applicable. If essential evidence cannot be obtained, report `INSUFFICIENT_EVIDENCE` and do not
claim a safe migration. Do not change a production store, schema, dependency, release setting or
user data merely because this document was read.

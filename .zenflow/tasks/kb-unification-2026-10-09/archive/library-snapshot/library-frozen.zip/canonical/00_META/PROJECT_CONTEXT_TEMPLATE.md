# Project context — compatibility route

The copy-only source of truth is [../PROJECT_FACTS.md](../PROJECT_FACTS.md). This file resolves
the old `00_META/PROJECT_CONTEXT_TEMPLATE.md` reference in imported materials; it is **not** a
template to write into a client repository.

Gather only relevant facts from local project instructions and inspected files. Unknown facts
remain `UNKNOWN`. Never copy another app's context or create a project profile automatically.

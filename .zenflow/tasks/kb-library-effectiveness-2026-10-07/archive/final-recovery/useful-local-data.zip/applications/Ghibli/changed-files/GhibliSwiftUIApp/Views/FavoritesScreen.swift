//
//  FavoritesScreen.swift
//  GhibliSwiftUIApp
//
//  Created by Karin Prater on 10/8/25.
//

import SwiftUI

struct FavoritesScreen: View {
    
    let filmsViewModel: FilmsViewModel
    let favoritesViewModel: FavoritesViewModel
    
    var body: some View {
        NavigationStack {
            Group {
                switch filmsViewModel.state {
                case .idle, .loading:
                    ProgressView("Loading favorites")
                case .error:
                    ContentUnavailableView {
                        Label("Unable to Load Favorites", systemImage: "exclamationmark.triangle")
                    } description: {
                        Text("The movie catalog could not be loaded. Please try again.")
                    } actions: {
                        Button("Retry") {
                            // Refresh the shared catalog even if the user leaves this tab.
                            Task {
                                await filmsViewModel.fetch()
                            }
                        }
                    }
                case .loaded(let films):
                    let favorites = films.filter { favoritesViewModel.favoriteIDs.contains($0.id) }
                    if favorites.isEmpty {
                        ContentUnavailableView("No Favorites yet", systemImage: "heart")
                    } else {
                        FilmListView(films: favorites,
                                     favoritesViewModel: favoritesViewModel)
                    }
                }
            }
            .navigationTitle("Favorites")
        }
    }
}

#Preview {
    FavoritesScreen(filmsViewModel: FilmsViewModel.example,
                    favoritesViewModel: FavoritesViewModel.example)
}

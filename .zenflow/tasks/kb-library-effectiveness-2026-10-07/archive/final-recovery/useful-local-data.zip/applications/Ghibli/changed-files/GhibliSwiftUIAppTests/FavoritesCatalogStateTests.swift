import Foundation
import Testing
@testable import GhibliSwiftUIApp

@MainActor
@Suite(.timeLimit(.minutes(1)))
struct FavoritesCatalogStateTests {
    private let film = Film(
        id: "saved-film", title: "Saved film", description: "", director: "",
        producer: "", releaseYear: "", score: "", duration: "", image: "",
        bannerImage: "", people: []
    )

    @Test("Loading and successful catalog refresh preserve saved favorites")
    func loadingThenSuccess() async {
        let service = ControlledCatalogService()
        let catalog = FilmsViewModel(service: service)
        let storage = RecordingFavoriteStorage(ids: [film.id])
        let favorites = FavoritesViewModel(service: storage)
        favorites.load()
        #expect(catalog.state == .idle)

        let request = Task { await catalog.fetch() }
        await service.waitForRequest()
        #expect(catalog.state == .loading)
        #expect(favorites.favoriteIDs == [film.id])
        // A duplicate refresh must not replace the in-flight request.
        await catalog.fetch()
        #expect(service.requestCount == 1)
        #expect(catalog.state == .loading)

        service.succeed(with: [film])
        await request.value
        #expect(catalog.state == .loaded([film]))
        #expect(favorites.favoriteIDs == [film.id])
        #expect(storage.savedValues.isEmpty)
    }

    @Test("Failure and retry publish distinct states without clearing saved favorites")
    func failureThenRetry() async {
        let service = ControlledCatalogService()
        let catalog = FilmsViewModel(service: service)
        let storage = RecordingFavoriteStorage(ids: [film.id])
        let favorites = FavoritesViewModel(service: storage)
        favorites.load()

        let firstRequest = Task { await catalog.fetch() }
        await service.waitForRequest()
        #expect(catalog.state == .loading)
        service.fail()
        await firstRequest.value
        #expect(catalog.state.error != nil)
        #expect(catalog.state.data == nil)
        #expect(favorites.favoriteIDs == [film.id])

        let retry = Task { await catalog.fetch() }
        await service.waitForRequest()
        #expect(catalog.state == .loading)
        #expect(catalog.state.error == nil)
        service.succeed(with: [film])
        await retry.value
        #expect(catalog.state == .loaded([film]))
        #expect(service.requestCount == 2)
        #expect(favorites.favoriteIDs == [film.id])
        #expect(storage.savedValues.isEmpty)
    }

    @Test("A successfully loaded empty catalog is not an error or loading state")
    func loadedEmptyCatalog() async {
        let service = ControlledCatalogService()
        let catalog = FilmsViewModel(service: service)
        let storage = RecordingFavoriteStorage(ids: [film.id])
        let favorites = FavoritesViewModel(service: storage)
        favorites.load()
        let request = Task { await catalog.fetch() }
        await service.waitForRequest()
        service.succeed(with: [])
        await request.value
        #expect(catalog.state == .loaded([]))
        #expect(favorites.favoriteIDs == [film.id])
        #expect(storage.savedValues.isEmpty)
    }
}

@MainActor
private final class ControlledCatalogService: GhibliService {
    private var pending: CheckedContinuation<[Film], Error>?
    private var observer: CheckedContinuation<Void, Never>?
    private(set) var requestCount = 0

    func fetchFilms() async throws -> [Film] {
        requestCount += 1
        guard pending == nil else { throw FixtureError.unexpectedRequest }
        return try await withCheckedThrowingContinuation { continuation in
            pending = continuation
            observer?.resume()
            observer = nil
        }
    }

    func waitForRequest() async {
        if pending != nil { return }
        await withCheckedContinuation { observer = $0 }
    }

    func succeed(with films: [Film]) {
        let continuation = pending
        pending = nil
        continuation?.resume(returning: films)
    }

    func fail() {
        let continuation = pending
        pending = nil
        continuation?.resume(throwing: FixtureError.catalogUnavailable)
    }

    func searchFilm(for searchTerm: String) async throws -> [Film] {
        throw FixtureError.unexpectedRequest
    }

    func fetchPerson(from URLString: String) async throws -> Person {
        throw FixtureError.unexpectedRequest
    }

    private enum FixtureError: Error {
        case catalogUnavailable
        case unexpectedRequest
    }
}

@MainActor
private final class RecordingFavoriteStorage: FavoriteStorage {
    private let ids: Set<String>
    private(set) var savedValues: [Set<String>] = []

    init(ids: Set<String>) { self.ids = ids }
    func load() -> Set<String> { ids }
    func save(favoriteIDs: Set<String>) { savedValues.append(favoriteIDs) }
}

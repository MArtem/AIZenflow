from pathlib import Path
import hashlib,json,shutil
root=Path('/Users/Artem/.zenflow/worktrees/knowledge-base-next')
task=root/'.zenflow/tasks/kb-library-effectiveness-2026-10-07'
evidence=task/'cxl01-evidence'; evidence.mkdir(exist_ok=True)
a=root/'.zenflow/task-artifacts/kb-library-effectiveness-2026-10-07/cxl01'
shutil.move(a/'CancellationPublication.swift',evidence/'CancellationPublication.swift')
shutil.copyfile(a/'results.txt',evidence/'results.txt')
lib=Path('/Users/Artem/.zenflow/worktrees/documentation-vault/reusable/ios-engineering-library/reference-copy-only')
stage=a/'candidate'; stage.mkdir(exist_ok=True)
swift=(evidence/'CancellationPublication.swift').read_text()
example=swift.split('// CXL01_EXAMPLE_BEGIN\n')[1].split('// CXL01_EXAMPLE_END')[0]
module='''# CXL-01 — cancellation and latest-invocation publication

Status: candidate practical module, version 0.1, 2026-10-07. This is an independently authored
mechanism example, not an app patch, an installation, or proof of Library benefit.

## Select before deciding a change

After the authoritative KB concurrency rules and observed source/consumer facts, select this
module when an asynchronous invocation can be replaced or cancelled before it publishes state,
errors or callbacks. Read it before choosing the fix. Keep normative requirements in the KB;
this module supplies a concrete mechanism and falsification traces. Existing project mode,
permissions and exact payload pin still govern selection; this candidate does not activate itself.

Do not select it solely because `Task` appears. A synchronous nil-input branch with no outstanding
work, a proven single-operation intake, or an unrelated synchronous refactor is a negative control.
A clean existing identity/cancellation guard is a reason to leave code unchanged.

## Establish the contract first

Name the real state owner/actor, invocation entry, replacement and dismissal events, every producer
that may ignore cancellation, and every publication consumer. Decide what the current operation's
cancellation means: keep prior state, restore last value, publish idle, or publish cancelled. This
example explicitly chooses cancelled; do not impose that UX on an app.

Distinguish three promises: request cancellation, reject obsolete publication, stop or undo side
effects. None implies the other two. A generic Cancellable requires invoking its cancellation API;
discarding a handle alone is not that API contract. Inspect callers before claiming an actual UI race.

## Mechanism

1. On the owning actor, invalidate the previous invocation and request cancellation of its handle.
2. Assign identity to this invocation, independent of query text. A→B→A contains three invocations.
3. After each relevant suspension, validate current identity and cancellation before publishing
   success **and generic error**. An await allows reentrancy even on the same actor.
4. Clean up only resources belonging to that invocation. An old defer must not clear a new handle.
5. Explicit owner cancellation invalidates publication immediately and applies the agreed terminal
   state. A producer may still complete later; drain or bound its lifetime separately.

An existing stable handle identity, actor-owned token, or proven serialized intake can implement
these invariants. Do not prescribe a new generation counter, architecture or wrapper when the
existing ownership already proves them. Query equality is insufficient for repeated inputs.

Unsafe shape: `state = try await producer()` followed by an unconditional `catch { state = failed }`
permits both stale success and stale generic failure. Calling cancel on the old task does not repair
that publication contract when the producer ignores cancellation.

## Checked example

The UI presentation state is genuinely MainActor-owned. The Sendable work closure owns its producer;
expensive synchronous work must be kept off the UI actor by the producer's actual API. This example
has one stored current handle. Repeated replacement can leave multiple cancelled producers alive:
real integration needs cancellation-cooperative bounded work, explicit backpressure, or a concurrency
limit. The example is not a resource-limit implementation.

The task retains its owner until work completes. Do not rely on deinit for cancellation: the caller
must invoke cancel at the agreed lifetime event. It must not return or expose handles that callers
cancel independently unless the state contract covers that path. `startIfIdle` is an intake alternative;
use it only when rejecting overlap is the intended product behavior.

```swift
import Foundation

enum ScreenState: Equatable { case idle, loading, loaded(String), failed, cancelled }

'''+example+'''```

No suspension occurs between the final guard and state mutation on the owner actor. If actual
publication crosses another actor, queue, callback or await, revalidate at that consumer boundary.
The example maps current CancellationError to cancelled. It preserves current genuine errors;
obsolete errors are ignored rather than shown as current failures.

## Eight falsification traces

The local fixture uses continuations to control completion, not timing sleeps. Its producer
intentionally ignores cancellation. Every created request is completed and every task awaited.

| Trace | Required observation |
| --- | --- |
| A starts; B starts; B succeeds; A succeeds | B remains visible |
| A starts; B starts; B succeeds; A throws generic error | B remains visible |
| A starts; owner cancels; producer returns | Agreed cancelled state remains |
| A-first → B → A-second; first A completes last | Latest A remains, despite equal query values |
| Current operation fails genuinely | Failure remains observable |
| Intake rejects overlap | Rejected invocation never runs; no inferred replacement defect |
| Durable write commits; presentation is cancelled | Commit remains; no rollback claim |
| A finishes while B is pending | B handle survives A cleanup and can still be cancelled |

The durable-write trace uses a committed actor ledger model, not disk/database transaction evidence.
Do not claim write rollback, SDK callback safety or device behavior from these checks.

## Evidence and limits

Swift 6.4, Swift language mode 6, strict concurrency complete, warnings as errors, macOS 27 SDK:
type-check and local executable 8/8 PASS on 2026-10-07. Fixture and commands:
[task evidence](../../../tasks/kb-library-effectiveness-2026-10-07/cxl01-evidence/README.md).
These checks validate this mechanism model. No app adoption, iPhone Simulator validation, benchmark,
holdout result or causal KB + Library improvement is established. iPad and physical-device checks
are OMITTED_BY_USER. Candidate payload pin/admission is separate from existing project payloads.

Normative owners:
[concurrency standard](../../baseline/docs/IOS_CONCURRENCY_RUNTIME_STANDARD.md),
[engineering quality](../../baseline/docs/ENGINEERING_CHANGE_QUALITY_STANDARD.md).
Return to the [concurrency route](COPY_ONLY_CONCURRENCY_ROUTE.md) for broader concurrency risks.

## Integration acceptance and goal check

Accept an integration only with the real caller/producer/consumer trace, agreed cancellation state,
guards at all publication paths, invocation-owned cleanup, and a resource/lifetime bound. Preserve
current errors, public API and existing architecture unless the task explicitly changes them.
If replacement cannot occur under the contract, record that evidence instead of adding machinery.
If a check only exercises an equivalent duplicate of the patch, it does not validate the patch.

Keep this module only if addressable delivery improves task outcomes or decision cost without
false-positive fixes. Missing delivery, worse outcomes, or reading overhead without a useful decision
is contrary evidence; refine within the approved iteration limit or remove its routing. Passing these
eight traces is a prerequisite for the example, not the success criterion for the overall plan.
'''
(stage/'CXL-01_CANCELLATION_PUBLICATION.md').write_text(module)
route=(lib/'03_CONCURRENCY/COPY_ONLY_CONCURRENCY_ROUTE.md').read_text()
route=route.replace('- Trace who creates, retains, cancels and awaits each task.', '''For replacement/cancellation publication work, after the authoritative KB rules and observed source
facts, read [CXL-01](CXL-01_CANCELLATION_PUBLICATION.md) before choosing the engineering fix.
It is a candidate applied mechanism, not a new norm or a permission grant. Do not select it for
unrelated synchronous work or a proven clean serialized path. Existing approved payload pins do
not automatically acquire this module.

- Trace who creates, retains, cancels and awaits each task.''')
(stage/'COPY_ONLY_CONCURRENCY_ROUTE.md').write_text(route)
router=(lib/'KNOWLEDGE_ROUTER.md').read_text()
router=router.replace('5. Apply the reference check after the local check at each applicable stage,', '''5. For observed replacement/cancellation publication work, the concurrency route selects the
   candidate practical [CXL-01](03_CONCURRENCY/CXL-01_CANCELLATION_PUBLICATION.md) after authoritative
   KB rules and source facts, before choosing a fix. This narrow V2 delivery exception does not
   remove normative reads, switch mode, or update a project payload pin.
   Apply the reference check after the local check at each applicable stage,''')
(stage/'KNOWLEDGE_ROUTER.md').write_text(router)
(evidence/'README.md').write_text('''# CXL-01 local mechanism evidence

User accepted the proposed block on 2026-10-07: one module, entry/router changes (maximum three
active Markdown files), one temporary Swift fixture, type-check and eight deterministic local
scenarios, 30–60 minutes. No app edits/builds/Simulator/network/installations or evaluation workers.

Contract: KB retains authority; candidate recipe selected before a cancellation publication fix;
actual state actor owns invocation identity, both success/error publication and identity-bound
cleanup; current errors remain visible; cancellation does not undo committed side effects. Real
integration must specify cancellation UX, producer lifetime and resource bounds. Existing app pins
remain unchanged. Sealed holdout bodies/oracles were not opened or emitted.

Swift file was preserved here from the temporary block to make the evidence reproducible. Its
PublicationOwner section is byte-identical to the module example. Model tests do not verify any
app patch, real storage, WebKit or runtime profile. Candidate status persists.

Commands (from active repository root; shell login:false):

```sh
CXL_DIR="$PWD/.zenflow/task-artifacts/kb-library-effectiveness-2026-10-07/cxl01"
CXL_SOURCE="$PWD/.zenflow/tasks/kb-library-effectiveness-2026-10-07/cxl01-evidence/CancellationPublication.swift"
CXL_COMPILER=/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/swiftc
CXL_SDK=/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk
mkdir -p "$CXL_DIR/cache" "$CXL_DIR/tmp"
TMPDIR="$CXL_DIR/tmp" "$CXL_COMPILER" -sdk "$CXL_SDK" -swift-version 6 -strict-concurrency=complete -warnings-as-errors -module-cache-path "$CXL_DIR/cache" -parse-as-library -typecheck "$CXL_SOURCE"
TMPDIR="$CXL_DIR/tmp" "$CXL_COMPILER" -sdk "$CXL_SDK" -swift-version 6 -strict-concurrency=complete -warnings-as-errors -module-cache-path "$CXL_DIR/cache" -parse-as-library "$CXL_SOURCE" -o "$CXL_DIR/CancellationPublication"
"$CXL_DIR/CancellationPublication"
```

Observed: Swift 6.4 (swiftlang-6.4.0.34.1), macOS27 host/SDK. Initial direct compiler invocation
without SDK failed to load the standard library; explicit installed SDK resolved it. No installer
or app build. Successful compilation/local run: [results.txt](results.txt), 8/8 PASS. Initial
xcrun type-check passed but reported SDK discovery/cache warnings; final explicit-SDK type-check
is recorded separately. Outputs/cache/tmp stay within .zenflow. SDK/compiler are read-only tools.

iPad/physical device/actual VoiceOver: OMITTED_BY_USER. Library benefit and delivery: NOT_MEASURED.
Final semantic review must inspect both error/success guards, cleanup, retention and exact example
parity; compilation alone does not replace that review. No high-risk app integration occurred.
''')
receipt={'status':'MECHANISM_CHECKED_CANDIDATE_NOT_ADOPTED','grant':'user acceptance CXL-01 2026-10-07','contract':'identity-bound publication and cleanup; actual UI actor; cancellation UX explicit; no side-effect rollback or resource-bound claim','checks':{'typecheck':'PASS xcrun; explicit SDK confirmation pending','executable':'8/8 PASS','sealed_hashes':'24 inputs and 24 oracles PASS; text not emitted','benefit':'NOT_MEASURED'},'source_sha256':hashlib.sha256((evidence/'CancellationPublication.swift').read_bytes()).hexdigest(),'candidate_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in stage.glob('*.md')},'omitted':['app builds','Simulator','network','holdout content access','new agents/MCP','iPad and physical device OMITTED_BY_USER']}
(evidence/'verification.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
for name in ('plan.md','handoff.md'):
 p=task/name; s=p.read_text().replace('Он работает.','Он завершён: 12 development + 12 sealed holdout кандидатов; hashes проверены без раскрытия sealed text.').replace('куратор `/root/p2_case_curator` работает','куратор `/root/p2_case_curator` завершён')
 s+='''\n## CXL-01 boundary, 2026-10-07\n\nПользователь принял блок: один модуль + entry/router, максимум три active Markdown files; один\nSwift fixture, type-check + 8 local deterministic scenarios; 30–60 минут. Без app source, app\nbuilds/Simulator/network/installations. Это НЕ восемь delivery attempts. Куратор завершён: 12+12\ncandidate cases, 3 clean controls в каждом split; public и 24 input/oracle hashes PASS без раскрытия\nsealed text. P2 остаётся PARTIAL_NOT_FROZEN; eligibility/oracle/isolation/future executor gates открыты.\nCXL-01: 8/8 local model PASS; candidate, benefit NOT_MEASURED. [Evidence](cxl01-evidence/README.md).\nНовый module/router не скопирован в active app payloads и не меняет их pins/modes. Следующий этап:\nпроверить доставку candidate C и определить ограниченный fresh-context A/C pilot; новые execution\nworkers/agents и их бюджет требуют конкретного решения, не следуют из Swift grant.\n'''
 p.write_text(s)
print('Prepared 3 active candidate Markdown files and bounded task evidence')

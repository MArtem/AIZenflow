from pathlib import Path
import json,hashlib,datetime,subprocess
r=Path('/Users/Artem/.zenflow/worktrees/knowledge-base-next');t=r/'.zenflow/tasks/kb-library-effectiveness-2026-10-07';p=t/'delivery-pilot-01';pre=json.loads((p/'preflight.json').read_text());rows=[]
for n in [1,2]:
 d=p/f'attempt-{n:02d}';x=json.loads((d/'output/ledger.json').read_text());inp=json.loads((d/'input.json').read_text()); assert hashlib.sha256((d/'input.json').read_bytes()).hexdigest()==pre['input_hashes'][d.name]
 for rel,h in inp['payload_hashes'].items():assert hashlib.sha256((d/'payload'/rel).read_bytes()).hexdigest()==h
 for path,h in inp['kb_hashes'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h
 assert x['elapsed_seconds']<600 and x['forbidden_actions_performed']==[]
 reads=x['actual_reads_in_order'];content=[q for q in reads if q.get('purpose')!='hash integrity read' and not q.get('kind','').startswith('hash')]
 for q in reads:
  path=q['path'];assert '/curator/' not in path and '/sealed-' not in path and '/reference-copy-only/' not in path
  assert '/delivery-pilot-01/attempt-' not in path or '/'+d.name+'/' in path
 row={'arm':pre['attempts'][d.name],'attempt':d.name,'model':x['model'],'reasoning':x['reasoning'],'elapsed_observed_seconds':x['elapsed_seconds'],'invocation_start_precision':'partial initial startup excluded; full elapsed UNKNOWN','within_cap':'PASS observed window; completion under coordinator interval','scoped_semantic_success':'PASS_STATIC','mandatory_checks':{'empty_bag':'PASS explicitly discussed','externally_retained_generic_cancellation':'PASS missing cancel invocation demonstrated','success_and_generic_failure_publication':'PASS exact sites and ordering traced','screen_claim_calibration':'PASS actual caller/UX UNKNOWN'},'confirmed_primary_contract_defects':1,'confirmed_publication_capabilities':1,'disproved_claim_FP':0,'independent_second_defect':'UNKNOWN; C P2 publication label is not additional detected behavior','source_runtime':'NOT_RUN','full_recall':'UNKNOWN','usage':'UNKNOWN','payload_count':len(inp['payload_hashes']),'output_hashes':{q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in (d/'output').iterdir()},'content_unique_kb_paths':sorted({q['path'] for q in content if '/reusable/baseline/' in q['path']}),'content_payload_paths':sorted({q['path'].split('/payload/')[1] for q in content if '/payload/' in q['path']}),'module_delivery':'PASS before final adjudication per ledger' if n==2 else 'NOT_APPLICABLE_BASELINE'}
 rows.append(row)
for name,folder in [('Countries','clean-architecture-swiftui'),('Ghibli','GhibliSwiftUIApp'),('Firefox','firefox-ios')]:
 path='/Users/Artem/.zenflow/library-acceptance-projects/'+folder
 actual={'HEAD':subprocess.check_output(['git','-C',path,'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',path,'status','--porcelain'],text=True)};assert actual==pre['original_source_state'][name]
shared=set(rows[0]['content_unique_kb_paths'])&set(rows[1]['content_unique_kb_paths']);extra={q['arm']:[x for x in q['content_unique_kb_paths'] if x not in shared] for q in rows}
grade={'schema_version':1,'status':'DELIVERY_PASS_SCOPED_OUTCOME_TIE_BENEFIT_NOT_ESTABLISHED','graded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'grader':'parent module author, unblinded; not independent','oracle':'public development DEV-C01 only, read after both final outputs; reasoning-checked not executable','oracle_sha256':hashlib.sha256((t/'curator/development/DEV-C01/oracle.json').read_bytes()).hexdigest(),'attempts':rows,'comparison':{'success_A':1,'success_C':1,'incremental_confirmed_defects_C':0,'incremental_confirmed_publication_capabilities_C':0,'incremental_proven_quality':'NONE_OBSERVED','time_effect':'NOT_ESTABLISHED; one run, partial invocation clocks, unequal selected extra KB reads','usage_cost':'UNKNOWN','module_increment':'11 selected Library documents in C versus 10 in A; short route to be prepared before content expansion'},'integrity':'PASS original project HEAD/status, inputs, full payload manifests and required KB pins unchanged; executor scope compliance from ledgers/output paths, not OS enforcement','actual_extra_kb_selection':extra,'limitations':pre['confounds']+['Actual extra KB reads differ, although available canonical inputs were shared; do not treat observed 138/132 seconds as a controlled efficiency effect','No independent grader; disputed second-defect severity remains UNKNOWN, not counted as TP or FP','Read-only review does not establish implementation delivery/fix correctness'],'holdout':'NOT_READ','decision':'Reduce review read slice and retain full checked implementation example. Do not expand module topics or claim rollout readiness from this tie. Next worker dispatch requires new explicit approval.'}
(p/'adjudication.json').write_text(json.dumps(grade,ensure_ascii=False,indent=2)+'\n')
(p/'results.md').write_text('''# Delivery pilot 01: delivered, scoped outcomes tied

Both fresh GPT-6.1 Sol/medium executors completed the same read-only DEV-C01 contract using
exact Countries source blobs. A used the 34-file baseline; C used the 35-file CXL-01 candidate.
Current authoritative KB, task input, tool permissions and 600s cap were shared. Inputs/payload
hashes and the three original project HEAD/status states were unchanged after execution.

| Observation | A | C |
| --- | --- | --- |
| Static mandatory semantic outcome | PASS | PASS |
| Confirmed generic cancellation contract failure | 1 | 1 |
| Confirmed late-publication capability (both branches) | 1 | 1 |
| Proven additional defect from C | — | 0 |
| Actual current-screen race | UNKNOWN | UNVERIFIED |
| Selected Library documents | 10 | 11 |
| Observed working interval | about 138s | about 132s |
| Tokens/subscription cost | UNKNOWN | UNKNOWN |

C read the practical module after source facts and before final finding adjudication. Its ledger
explicitly claims zero incremental findings. A already distinguished cancellation request,
late success/generic failure and unknown caller/UI consequences. The public development oracle
was read only after both outputs and accepts this qualified-risk alternative.

Do not count the two C P2 headings versus one A P2 and observation as an extra detected defect:
both describe the same source behavior. The stronger C publication severity is not independently
proved as a second required-consumer contract violation; keep that severity UNKNOWN. No concrete
source assertion was disproved, hence no confirmed FP is assigned. Both scoped static task
outcomes pass; neither source nor an app fix is accepted. The existing cancellation defect remains
unfixed in the evaluation source, outside this review's implementation scope.

Efficiency is NOT_ESTABLISHED. Single attempts, partly excluded startup intervals, unknown tokens,
and different extra KB selections prevent attributing the small time difference to the module.
The coordinator authored C and is unblinded; there is no independent grader or OS-enforced blind
isolation. Full real-code recall and runtime behavior remain UNKNOWN. No sealed holdout was read.
See adjudication.json for exact hashes, clocks, scope checks and selection differences.

Decision: delivery passed in this review workflow; incremental quality benefit was not observed.
Reduce the review-only practical read slice before adding topics or running a larger series.
Keep the complete verified example available for implementation. Do not remove required KB
norms or silently deduplicate semantically similar sources. A subsequent task that requires a
bounded fix, plus a clean control, would be more informative than repeating this same prompted
review. Those worker/budget/runtime decisions remain separately permission-bounded.

No source/build/test/Simulator/network/MCP/handler changes or child agents. The exactly two
executor grant is now consumed. iPad/physical device/actual VoiceOver: OMITTED_BY_USER.
Both review files and ledgers are preserved unchanged as evidence; headings are not adopted
as normative truth. Docs route: Level0 + governance/task-state + AI.EVALUATION + bounded review
and concurrency. Context health: current scoped context is adequate.
''')
print('Graded: both scoped static PASS; module delivered; confirmed incremental findings 0; benefit/time/cost not established')
print('Extra KB content reads:',{k:[Path(x).name for x in v] for k,v in extra.items()})

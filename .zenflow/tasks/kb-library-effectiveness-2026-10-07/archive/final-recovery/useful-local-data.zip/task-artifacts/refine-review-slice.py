from pathlib import Path
import json,hashlib
r=Path('/Users/Artem/.zenflow/worktrees/knowledge-base-next');t=r/'.zenflow/tasks/kb-library-effectiveness-2026-10-07';lib=Path('/Users/Artem/.zenflow/worktrees/documentation-vault/reusable/ios-engineering-library/reference-copy-only');stage=r/'.zenflow/task-artifacts/kb-library-effectiveness-2026-10-07/cxl01-v02';stage.mkdir(exist_ok=True)
rel='03_CONCURRENCY/CXL-01_CANCELLATION_PUBLICATION.md';old=(lib/rel).read_text();s=old.replace('Status: candidate practical module, version 0.1, 2026-10-07.','Status: candidate practical module, version 0.2.')
s=s.replace('## Checked example','''For a review-only task, stop here after this mechanism slice. Identify the actual promise violated:
a late publication capability is not automatically a proven current-screen defect or a second P2.
State caller reachability and contract uncertainty separately. Also record actual isolation,
retention and resource bounds: an unstructured task can retain its owner across await; cancellation
in deinit is insufficient. Rejecting stale publication does not bound cancellation-ignoring work.
The full example is for a relevant implementation/ownership question, not a mandatory review read.

## Checked example''')
a=s.index('## Evidence and limits');b=s.index('\n## Integration acceptance',a)
s=s[:a]+'''## Verification envelope and limits

Verify the exact example and eight controlled traces under the project's actual language mode,
compiler/SDK and permitted checks. Strict Swift 6 concurrency and warnings-as-errors are a useful
profile when compatible. Keep exact toolchain identity, source parity and observed results in the
task-owned evidence receipt; this reusable module is not a task-history index.

The controlled traces validate a mechanism model. App adoption, SDK callback behavior, real durable
storage, iPhone Simulator coverage, delivery or causal KB + Library improvement require their own
evidence and authority. iPad and physical-device checks follow the current user scope; omitted
checks never become PASS. Candidate payload admission is separate from existing project payloads.

Normative owners:
[concurrency standard](../../../baseline/docs/IOS_CONCURRENCY_RUNTIME_STANDARD.md),
[engineering quality](../../../baseline/docs/ENGINEERING_CHANGE_QUALITY_STANDARD.md).
Return to the [concurrency route](COPY_ONLY_CONCURRENCY_ROUTE.md) for broader concurrency risks.
''' +s[b:]
(stage/'CXL-01_CANCELLATION_PUBLICATION.md').write_text(s)
route=(lib/'03_CONCURRENCY/COPY_ONLY_CONCURRENCY_ROUTE.md').read_text().replace('facts, read [CXL-01](CXL-01_CANCELLATION_PUBLICATION.md) before choosing the engineering fix.','''facts, select [CXL-01](CXL-01_CANCELLATION_PUBLICATION.md#select-before-deciding-a-change) before
choosing the engineering fix or final review verdict. For review-only work, read from "Select before
deciding a change" through "Mechanism" and stop before "Checked example". Expand the example and
traces only for a relevant implementation/ownership or verification question. Carry the slice's
contract, isolation, lifetime and resource limits into the review; do not infer a defect from a missing
mechanism when the actual consumer contract does not require it.''')
(stage/'COPY_ONLY_CONCURRENCY_ROUTE.md').write_text(route)
router=(lib/'KNOWLEDGE_ROUTER.md').read_text().replace('KB rules and source facts, before choosing a fix. This narrow V2 delivery exception does not','''KB rules and source facts, before choosing a fix or final review verdict. Follow its route's bounded
   review slice; the complete example is conditional on an implementation/ownership question.
   This narrow V2 delivery exception does not''')
(stage/'KNOWLEDGE_ROUTER.md').write_text(router)
fixture=(t/'cxl01-evidence/CancellationPublication.swift').read_text().split('// CXL01_EXAMPLE_BEGIN\n')[1].split('// CXL01_EXAMPLE_END')[0];assert fixture in s
mapping={'KNOWLEDGE_ROUTER.md':stage/'KNOWLEDGE_ROUTER.md','03_CONCURRENCY/COPY_ONLY_CONCURRENCY_ROUTE.md':stage/'COPY_ONLY_CONCURRENCY_ROUTE.md',rel:stage/'CXL-01_CANCELLATION_PUBLICATION.md'}
x=json.loads((t/'cxl01-evidence/candidate-payload.json').read_text());x['version']='CXL-01-candidate-0.2';x['supersedes_for_future_trials']='v0.1 remains frozen as delivery-pilot-01 input; no trial rerun or retrospective update';x['selection']='Future candidate only; review read slice, not norm dedup or real project admission.'
for f in x['files']:
 if f['path'] in mapping:
  data=mapping[f['path']].read_bytes();f['sha256']=hashlib.sha256(data).hexdigest();f['bytes']=len(data)
(t/'cxl01-evidence/candidate-payload-v0.2.json').write_text(json.dumps(x,indent=2)+'\n')
slice_text=s[s.index('## Select before deciding'):s.index('## Checked example')];stats={'old_full_module_words':len(old.split()),'new_review_slice_words':len(slice_text.split()),'new_full_module_words':len(s.split()),'exact_example_parity':'PASS','verification_reused':'Swift6 strict complete typecheck and 8/8 local traces; exact Swift bytes unchanged','runtime_new':'NOT_RUN_NO_NEW_CODE_RISK','delivery_v02':'NOT_RUN','benefit':'NOT_ESTABLISHED','normative_required_reads':'UNCHANGED','boundary_fix':'Removed task ID/path/history link from reusable module; provenance/results remain task-owned','scope':'Only same three active Library Markdown files; no app source/payload/mode modifications','change_contract':'Route a bounded practical review slice before final decision; preserve full mechanism/code; explicit unknown consumer contract cannot become P2 by absent token; evidence cannot imply global or runtime benefit'}
(t/'cxl01-evidence/review-slice-v0.2.json').write_text(json.dumps(stats,indent=2)+'\n')
print(json.dumps(stats,indent=2))
